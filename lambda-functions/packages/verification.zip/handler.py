import json
import boto3
import os
from datetime import datetime

# Configure AWS clients WITHOUT endpoint_url - LocalStack handles this internally
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('supportmesh-tickets')

CONFIDENCE_THRESHOLD = 0.90

def generate_draft_response(classification, rag_documents):
    """Generate mock RAG-based response"""
    intent = classification['intent']
    
    responses = {
        'REFUND_REQUEST': (
            "We sincerely apologize for the inconvenience. "
            "Per our cancellation policy, you are entitled to a full refund within 7-10 business days. "
            "We will process your request immediately."
        ),
        'FLIGHT_DELAY': (
            "We understand how frustrating flight delays can be. "
            "You may be eligible for compensation depending on the delay duration. "
            "Our team will review your case and contact you within 24 hours."
        ),
        'CANCELLATION': (
            "We apologize for the flight cancellation. "
            "We can rebook you on the next available flight at no additional cost, "
            "or process a full refund if you prefer."
        ),
        'BAGGAGE_ISSUE': (
            "We sincerely apologize for the baggage issue. "
            "Please file a Property Irregularity Report (PIR) at the airport. "
            "We will track your baggage and provide updates every 6 hours."
        ),
        'GENERAL_INQUIRY': (
            "Thank you for contacting us. "
            "We have received your inquiry and our customer service team will respond within 24-48 hours."
        )
    }
    
    return responses.get(intent, responses['GENERAL_INQUIRY'])

def lambda_handler(event, context):
    """Verification Lambda: Score confidence, flag for HITL if needed, store in DynamoDB"""
    print(f"Verification Lambda triggered with event: {json.dumps(event)}")
    
    try:
        for record in event['Records']:
            body = json.loads(record['body'])
            
            if 'Message' in body:
                ticket_data = json.loads(body['Message'])
            else:
                ticket_data = body
            
            print(f"Processing ticket: {ticket_data['ticketId']}")
            
            classification = ticket_data['classification']
            confidence = classification['confidence']
            
            needs_hitl = confidence < CONFIDENCE_THRESHOLD
            draft_response = generate_draft_response(classification, ticket_data['ragDocuments'])
            
            if needs_hitl:
                status = 'NEEDS_HUMAN_REVIEW'
                print(f"Ticket {ticket_data['ticketId']} flagged for human review (confidence: {confidence})")
            else:
                status = 'AUTO_APPROVED'
                print(f"Ticket {ticket_data['ticketId']} auto-approved (confidence: {confidence})")
            
            ticket_item = {
                'ticketId': ticket_data['ticketId'],
                'timestamp': ticket_data['timestamp'],
                'customerEmail': ticket_data['customerEmail'],
                'originalMessage': ticket_data['originalMessage'],
                'intent': classification['intent'],
                'confidence': str(confidence),
                'sentiment': classification['sentiment'],
                'sentimentScore': str(classification['sentimentScore']),
                'priority': classification['priority'],
                'ragDocuments': ticket_data['ragDocuments'],
                'draftResponse': draft_response,
                'status': status,
                'needsHITL': needs_hitl,
                'createdAt': ticket_data['processedAt'],
                'updatedAt': datetime.now().isoformat(),
                'approvedBy': None,
                'approvedAt': None
            }
            
            response = table.put_item(Item=ticket_item)
            print(f"Stored ticket in DynamoDB: {ticket_data['ticketId']}")
        
        return {'statusCode': 200, 'body': 'Success'}
    
    except Exception as e:
        print(f"Error in verification lambda: {str(e)}")
        import traceback
        print(traceback.format_exc())
        raise e
